//
//  PodIJKPlayer.h
//  Pods
//
//  Created by 畅三江 on 2022/7/12.
//

#ifndef PodIJKPlayer_h
#define PodIJKPlayer_h

#import <IJKMediaFramework/IJKMediaFramework.h>

#endif /* PodIJKPlayer_h */
